# Manajemen Kendaraan V1 — Website
Website responsive untuk Body Repair dan Used Car.

## V1 saat ini
- Dashboard
- Body Repair
- Used Car
- Tambah/edit/hapus unit
- Pencarian nomor polisi
- Filter status
- Responsive HP/desktop
- Penyimpanan lokal browser (localStorage)

## Langkah berikutnya
1. Upload folder ini ke repository GitHub.
2. Hubungkan ke hosting permanen seperti Vercel/Cloudflare Pages.
3. Sambungkan Supabase untuk login, database online, dan foto.
4. Tambahkan domain sendiri.

V1 sengaja memakai localStorage agar bisa langsung dicoba tanpa konfigurasi database.
